//
//  PASelectBar.m
//  SelectBar
//
//  Created by 张行 on 17/1/4.
//  Copyright © 2017年 张行. All rights reserved.
//

#import "PASelectBar.h"

#define KscreenWidth    ([[UIScreen mainScreen] bounds].size.width)

#define KscreenHeight   ([[UIScreen mainScreen] bounds].size.height)

#define KbuttonWidth 65

#define KjudgeCount 5

@implementation PASelectBar {

    UIScrollView *_indexView;
    UIView *_indexLineView;
    UIScrollView *_bgScrollView;
    NSInteger _currentIndex;
    BOOL _isFirstClickCrewAnonounce;
}

- (instancetype)initWithFrame:(CGRect)frame withTitle:(NSArray *)title {
  
    self = [super initWithFrame:frame];

    if (self) {
        
        self.titleArr = title;
        [self initUI];
    }
    
    return self;
}


- (void)initUI {
    
    _indexView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, KscreenWidth, 40)];
//    _indexView.scrollsToTop = YES;
    _indexView.backgroundColor = [UIColor colorWithRed:240/255.0 green:240/255.0 blue:240/255.0 alpha:1];
//    _indexView.backgroundColor = [UIColor redColor];
    _indexView.showsHorizontalScrollIndicator = NO;
    _indexView.delegate = self;
    _indexView.scrollEnabled = YES;
    _indexView.tag = 110;
    if (self.titleArr.count > KjudgeCount) {
        _indexView.contentSize = CGSizeMake(KbuttonWidth * _titleArr.count, 40);
    } else {
        _indexView.contentSize = CGSizeMake(KscreenWidth,40);
    }
    [self addSubview:_indexView];
    

//    UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, _indexView.frame.size.height - 4, KscreenWidth, 4)];
//    lineView.backgroundColor = [UIColor greenColor];
//    [_indexView addSubview:lineView];
    

    _indexLineView = [[UIView alloc] init];
    if (self.titleArr.count > KjudgeCount) {
        _indexLineView.frame = CGRectMake(10, _indexView.frame.size.height - 3, KbuttonWidth-30, 3);
    } else {
        _indexLineView.frame = CGRectMake(10, _indexView.frame.size.height - 3, KscreenWidth/_titleArr.count-20, 3);
    }
    _indexLineView.backgroundColor = [UIColor redColor];
    _indexLineView.tag = 101;
    [_indexView addSubview:_indexLineView];
    
    for (int i = 0; i < self.titleArr.count; i ++)
    {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        if (self.titleArr.count > KjudgeCount) {
            button.frame =CGRectMake(KbuttonWidth * i, 0, KbuttonWidth, 40);
        } else {
            button.frame = CGRectMake( (KscreenWidth)/_titleArr.count * i, 0, (KscreenWidth )/_titleArr.count , 40);
        }
        
        button.tag = i;
        [button setTitle:_titleArr[i] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor orangeColor] forState:UIControlStateSelected];
        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        button.showsTouchWhenHighlighted = YES;
        button.titleLabel.font = [UIFont systemFontOfSize:15];
        [button addTarget:self action:@selector(indexChange:) forControlEvents:UIControlEventTouchUpInside];
        [button setTintColor:[UIColor clearColor]];
        [_indexView addSubview:button];
        
        if (button.tag == 0)
        {
            button.selected = YES;
        }
    }
    
    _bgScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, _indexView.frame.origin.y+_indexView.frame.size.height, KscreenWidth, KscreenHeight -  64 - _indexView.frame.size.height)];
    _bgScrollView.showsHorizontalScrollIndicator = NO;
    _bgScrollView.showsVerticalScrollIndicator = NO;
    _bgScrollView.delegate = self;
    _bgScrollView.tag = 3;
    _bgScrollView.contentSize = CGSizeMake(KscreenWidth *_titleArr.count, _bgScrollView.frame.size.height);
    _bgScrollView.pagingEnabled = YES;
    _bgScrollView.scrollsToTop = NO;
    [self addSubview:_bgScrollView];
}


- (void)setTextDefaultColor:(UIColor *)textDefaultColor {
    _textDefaultColor = textDefaultColor;
    
    for (UIButton *btn in _indexView.subviews) {
        if ([btn isKindOfClass:[UIButton class]]) {
            [btn setTitleColor:self.textDefaultColor forState:UIControlStateNormal];
        }
    }
}

- (void)setTextSelectColor:(UIColor *)textSelectColor {
    _textSelectColor = textSelectColor;
    
    for (UIButton *btn in _indexView.subviews) {
        if ([btn isKindOfClass:[UIButton class]]) {
            [btn setTitleColor:self.textSelectColor forState:UIControlStateSelected];
        }
    }
}

- (void)setLineColor:(UIColor *)lineColor {
    _lineColor = lineColor;

    for (UIView *lineView in _indexView.subviews) {
        if (lineView.tag == 101) {
            lineView.backgroundColor = _lineColor;
        }
    }
}


- (void)setSubviewArr:(NSMutableArray *)subviewArr {
    _subviewArr = subviewArr;
    
    
    for (int i = 0; i<subviewArr.count; i++) {
        UIView *view = subviewArr[i];
        view.frame = CGRectMake(i*KscreenWidth, 0.f, KscreenWidth, _bgScrollView.frame.size.height);
        [_bgScrollView addSubview:view];
    }
}

- (void)setTitleFont:(UIFont *)titleFont {
    _titleFont = titleFont;

    for (UIButton *btn in _indexView.subviews) {
        if ([btn isKindOfClass:[UIButton class]]) {
            btn.titleLabel.font = _titleFont;
        }
    }
}

#pragma mark 选择栏点击事件
- (void)indexChange:(UIButton *)button{
    
    for (UIButton *subButton in _indexView.subviews)
    {
        if ([subButton isKindOfClass:[UIButton class]])
        {
            subButton.selected = NO;
        }
    }
    
    button.selected = YES;
    NSInteger tag = button.tag;
    
    if (_currentIndex == tag) { //如果是点击当前栏，无效
        return;
    }
    _currentIndex = tag;
    
    [self sendDelegateIndex];
    
    [self shakeToShow];
    
    [self handButtonCenter:button];
    
    [UIView animateWithDuration:0.25 animations:^{
        
        CGRect rect = _indexLineView.frame;
//        CGFloat edge = (KscreenWidth/2.0-100)/_titleArr.count;
        
        CGFloat edge;
        if (self.titleArr.count > KjudgeCount) {
            edge = KbuttonWidth*_currentIndex+10;
        } else {
            edge = KscreenWidth/_titleArr.count*_currentIndex+10;
        }
        rect.origin.x = edge;
        _indexLineView.frame = rect;
        
    }];
    [_bgScrollView scrollRectToVisible:CGRectMake(KscreenWidth*_currentIndex, 0, KscreenWidth, _bgScrollView.frame.size.height) animated:YES];
    if (_currentIndex == 1 && _isFirstClickCrewAnonounce)
    {
        
        _isFirstClickCrewAnonounce = NO;
        
    }
    if (_currentIndex == 1) {
        
    }
    
    if (_currentIndex == 0)
    {
        
    }else
    {
        
    }
}



- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset NS_AVAILABLE_IOS(5_0)
{
    if(scrollView.tag != 3)
    {
        return;
    }
//    if(targetContentOffset->x <KscreenWidth/2.0)
//    {
//        _currentIndex = 0;
//        
//    }else
//    {
//        _currentIndex = 1;
//    }
    
    _currentIndex = targetContentOffset->x/KscreenWidth;
    
    [self sendDelegateIndex];
    [self shakeToShow];
    
    //
    [UIView animateWithDuration:0.4 animations:^{
//        CGRect rect = _indexLineView.frame;
//        CGFloat edge = (KscreenWidth/2.0-100)/2.0;
//        rect.origin.x = edge + _currentIndex * KscreenWidth/2;
//        _indexLineView.frame = rect;
        
        
        CGRect rect = _indexLineView.frame;
        //        CGFloat edge = (KscreenWidth/2.0-100)/_titleArr.count;
        
        CGFloat edge;
        if (self.titleArr.count > KjudgeCount) {
            edge = KbuttonWidth*_currentIndex+10;
        } else {
            edge = KscreenWidth/_titleArr.count*_currentIndex+10;
        }
        rect.origin.x = edge;
        _indexLineView.frame = rect;
    }];
    
    for (UIButton *subButton in _indexView.subviews)
    {
        if ([subButton isKindOfClass:[UIButton class]])
        {
            if(subButton.tag == _currentIndex)
            {
                subButton.selected = YES;
                [self handButtonCenter:subButton];
            }else
            {
                subButton.selected = NO;
            }
        }
    }
    
    if (_currentIndex == 1 && _isFirstClickCrewAnonounce)
    {
        _isFirstClickCrewAnonounce = NO;
    }
    
    if (_currentIndex == 0)
    {
        
        
    }else
    {
    }
}


- (void)sendDelegateIndex{

    if ([self.delegate respondsToSelector:@selector(sendIndex:)]) {
        [self.delegate sendIndex:_currentIndex];
    }
}


//设置选中按钮居中
- (void)handButtonCenter:(UIButton *)centerBtn
{
    //0.获取按钮的中心点坐标
    CGFloat buttonCenterX = centerBtn.center.x;
    //1.获取X偏移量 = 点击的按钮的中心点坐标 - menuView的宽度的一样。
    CGFloat OffsetX = buttonCenterX - self.frame.size.width / 2;
    //2.校验坐标
    if(buttonCenterX < KscreenWidth / 2)
    {
        OffsetX = 0;
    }
    else if(buttonCenterX > _indexView.contentSize.width - KscreenWidth / 2)
    {
        OffsetX = _indexView.contentSize.width - KscreenWidth;
    }
    //3.修改偏移量
    [_indexView setContentOffset:CGPointMake(OffsetX, 0) animated:YES];
}

- (void)shakeToShow{
    
    UIButton *btn;
    for (int i = 0; i<self.titleArr.count; i++) {
        btn = [_indexView viewWithTag:_currentIndex];
        NSLog(@"");
    }
    
    CAKeyframeAnimation* animation = [CAKeyframeAnimation animationWithKeyPath:@"transform"];
    animation.duration = 0.5;
    
    NSMutableArray *values = [NSMutableArray array];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.1, 0.1, 1.0)]];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.2, 1.2, 1.0)]];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.9, 0.9, 1.0)]];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.0, 1.0, 1.0)]];
    animation.values = values;
    [btn.layer addAnimation:animation forKey:nil];
}




@end
