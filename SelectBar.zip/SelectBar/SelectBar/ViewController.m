//
//  ViewController.m
//  SelectBar
//
//  Created by 张行 on 17/1/4.
//  Copyright © 2017年 张行. All rights reserved.
//

#import "ViewController.h"
#import "PASelectBar.h"


#define KscreenWidth    ([[UIScreen mainScreen] bounds].size.width)

#define KscreenHeight   ([[UIScreen mainScreen] bounds].size.height)

@interface ViewController ()<UIScrollViewDelegate,selectBarDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.title = @"选择栏";
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    
    NSArray *titleArr = @[@"新闻",@"音乐",@"电影",@"视频",@"搞笑",@"汽车",@"视频",@"搞笑",@"汽车",@"动漫"];
    PASelectBar *selectBar = [[PASelectBar alloc] initWithFrame:CGRectMake(0.f, 80, KscreenWidth, 664) withTitle:titleArr];
    selectBar.backgroundColor = [UIColor grayColor];
    selectBar.textDefaultColor = [UIColor blackColor];
    selectBar.textSelectColor = [UIColor orangeColor];
    selectBar.lineColor = [UIColor redColor];
    selectBar.delegate = self;
    selectBar.titleFont = [UIFont systemFontOfSize:15];
    [self.view addSubview:selectBar];
    
    NSArray *colorArr = @[[UIColor orangeColor],[UIColor yellowColor],[UIColor blueColor],[UIColor greenColor],[UIColor cyanColor],[UIColor magentaColor],[UIColor greenColor],[UIColor cyanColor],[UIColor magentaColor],[UIColor redColor]];
    NSMutableArray *mutableArr = [[NSMutableArray alloc] init];
    for (int i = 0; i<titleArr.count; i++) {
        UITableView *tableview1 = [[UITableView alloc] init];
        tableview1.backgroundColor = colorArr[i];
        [mutableArr addObject:tableview1];
    }
    selectBar.subviewArr = mutableArr;
    
}

- (void)sendIndex:(NSInteger)index {

    NSLog(@"%ld",index);
}



@end
