//
//  PASelectBar.h
//  SelectBar
//
//  Created by 张行 on 17/1/4.
//  Copyright © 2017年 张行. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol selectBarDelegate <NSObject>

- (void)sendIndex:(NSInteger)index;

@end



@interface PASelectBar : UIView<UIScrollViewDelegate>


@property(nonatomic,strong)NSArray *titleArr;
@property(nonatomic,strong)UIColor *textDefaultColor;
@property(nonatomic,strong)UIColor *textSelectColor;
@property(nonatomic,strong)UIColor *lineColor;
@property(nonatomic,strong)NSMutableArray *subviewArr;
@property(nonatomic,strong)UIFont *titleFont;

@property(nonatomic,weak)id<selectBarDelegate>delegate;

- (instancetype)initWithFrame:(CGRect)frame withTitle:(NSArray *)title;

@end
